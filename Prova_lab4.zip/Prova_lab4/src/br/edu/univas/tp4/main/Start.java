package br.edu.univas.tp4.main;

import br.edu.univas.tp4.frame.tela;

public class Start {

	public static void main(String[] args) {
		
		tela tela = new tela();
		tela.setVisible(true);

	}

}
